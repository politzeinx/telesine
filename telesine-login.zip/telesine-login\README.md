# 🎬 Telesine — versão inicial (Login)

Versão enxuta do site Telesine, contendo apenas:

- **Responsividade** completa para celular e tablet.
- **Tela de login/cadastro** funcional (única funcionalidade ativa).

As demais áreas (filmes, artigos, parceiros) são apenas visuais nesta versão — sem busca, detalhes, avaliações, favoritos ou perfil.

## Como executar

Abra o arquivo `index.html` no navegador. Não precisa de servidor.

## Login

- Clique em **+ LOG** na barra de navegação para abrir a tela.
- É possível **cadastrar** uma conta e **entrar**; os dados ficam salvos no `localStorage` do navegador.
- Após entrar, o nome aparece na barra e há a opção de sair.
